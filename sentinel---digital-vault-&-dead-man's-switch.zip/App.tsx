
import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  Lock, 
  Unlock, 
  Clock, 
  User, 
  Plus, 
  AlertTriangle, 
  FileText, 
  LogOut,
  RefreshCw,
  Copy,
  Check,
  UserPlus,
  ChevronRight,
  Fingerprint,
  Image as ImageIcon,
  Save,
  X,
  Trash2,
  Edit3,
  UserCheck,
  ShieldCheck,
  Activity
} from 'lucide-react';
import { VaultStatus, Secret, UserProfile, DeadlineUnit } from './types';

// --- Constants & Helpers ---

const UNIT_TO_SECONDS: Record<DeadlineUnit, number> = {
  MINUTES: 60,
  HOURS: 3600,
  DAYS: 86400,
  WEEKS: 604800,
  MONTHS: 2592000,
  YEARS: 31536000,
};

const LoadingOverlay: React.FC<{ message: string }> = ({ message }) => (
  <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex flex-col items-center justify-center space-y-6 crt-flicker">
    <div className="relative">
      <div className="w-24 h-24 border-4 border-green-500/10 border-t-green-500 rounded-full animate-spin"></div>
      <Shield className="absolute inset-0 m-auto w-8 h-8 text-green-500 animate-pulse" />
    </div>
    <div className="flex flex-col items-center space-y-2">
      <p className="text-green-400 mono text-xs tracking-[0.3em] uppercase animate-pulse">{message}</p>
      <div className="w-48 h-1 bg-green-950 rounded-full overflow-hidden">
        <div className="h-full bg-green-500 animate-[loading_2s_ease-in-out_infinite]" style={{ width: '30%' }}></div>
      </div>
    </div>
    <style>{`
      @keyframes loading {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(300%); }
      }
    `}</style>
  </div>
);

const SecurityBackground: React.FC = () => (
  <div className="fixed inset-0 -z-10 bg-black overflow-hidden">
    <video 
      autoPlay 
      loop 
      muted 
      playsInline
      className="absolute inset-0 w-full h-full object-cover opacity-95 contrast-110 brightness-105 scale-100 transition-opacity duration-1000"
    >
      <source src="https://cdn.pixabay.com/video/2019/10/10/27725-365890983_tiny.mp4" type="video/mp4" />
    </video>
    <div className="absolute inset-0 bg-black/5"></div>
    <div className="scan-effect opacity-20"></div>
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(34,197,94,0.05)_0%,_transparent_100%)]"></div>
  </div>
);

const AuthBackground: React.FC = () => (
  <div className="fixed inset-0 -z-10 bg-black overflow-hidden">
    <video 
      autoPlay 
      loop 
      muted 
      playsInline
      className="absolute inset-0 w-full h-full object-cover opacity-100 contrast-115 brightness-110 scale-105 transition-transform duration-[30s] animate-[zoom-slow_40s_infinite_alternate]"
    >
      <source src="https://cdn.pixabay.com/video/2019/10/10/27725-365890983_tiny.mp4" type="video/mp4" />
    </video>
    <div className="absolute inset-0 bg-black/10"></div>
    <div className="scan-effect opacity-25"></div>
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(34,197,94,0.1)_0%,_transparent_80%)]"></div>
    <style>{`
      @keyframes zoom-slow {
        from { transform: scale(1.05); }
        to { transform: scale(1.2); }
      }
    `}</style>
  </div>
);

const App: React.FC = () => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authIdentity, setAuthIdentity] = useState(''); 
  const [authKey, setAuthKey] = useState('');
  
  // App State
  const [status, setStatus] = useState<VaultStatus>(VaultStatus.LOCKED);
  const [secrets, setSecrets] = useState<Secret[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<'vault' | 'beneficiary' | 'emergency'>('vault');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [graceTimeLeft, setGraceTimeLeft] = useState<number>(0);
  
  // Notepad State
  const [isNotepadOpen, setIsNotepadOpen] = useState(false);
  const [editingSecretId, setEditingSecretId] = useState<string | null>(null);
  const [notepadTitle, setNotepadTitle] = useState('');
  const [notepadContent, setNotepadContent] = useState('');
  const [notepadImages, setNotepadImages] = useState<string[]>([]);
  const notepadFileInputRef = useRef<HTMLInputElement>(null);

  // Beneficiary Setup Logic within the tab
  const [isAddingBeneficiary, setIsAddingBeneficiary] = useState(false);
  const [tabBeneficiaryUsername, setTabBeneficiaryUsername] = useState('');
  const [tabBeneficiaryEmail, setTabBeneficiaryEmail] = useState('');

  // Persistence
  const [usersDB, setUsersDB] = useState<Record<string, { user: UserProfile, key: string }>>(() => {
    const saved = localStorage.getItem('sentinel_users_db');
    if (!saved) {
      const demoUser: UserProfile = {
        id: 'u-demo',
        username: 'sentinel_demo',
        name: 'Demo Account',
        email: 'demo@sentinel.io',
        checkInInterval: 24,
        checkInUnit: 'HOURS',
        gracePeriodHours: 48,
        lastCheckIn: new Date().toISOString(),
        beneficiaryEmail: '',
        beneficiaryName: '',
        beneficiaryStatus: 'PENDING'
      };
      return { 'u-demo': { user: demoUser, key: 'SENTINEL-MASTER-DEMO-KEY-12345' } };
    }
    return JSON.parse(saved);
  });

  useEffect(() => {
    localStorage.setItem('sentinel_users_db', JSON.stringify(usersDB));
  }, [usersDB]);

  // Signup Flow States
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [signupStep, setSignupStep] = useState<'INFO' | 'SETUP'>('INFO');
  const [signupUsername, setSignupUsername] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupName, setSignupName] = useState('');
  const [signupBeneficiaryUsername, setSignupBeneficiaryUsername] = useState('');
  const [signupBeneficiaryEmail, setSignupBeneficiaryEmail] = useState('');
  const [signupInterval, setSignupInterval] = useState(24);
  const [signupUnit, setSignupUnit] = useState<DeadlineUnit>('HOURS');
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [hasCopiedKey, setHasCopiedKey] = useState(false);
  const [showDeadlineModal, setShowDeadlineModal] = useState(false);

  // --- Handlers ---

  const copyToClipboard = (text: string | null) => {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      setHasCopiedKey(true);
      setTimeout(() => setHasCopiedKey(false), 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };

  const validateUsername = (name: string) => /^[a-z0-9_]+$/.test(name);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setLoadingMsg("VERIFYING MASTER KEY...");

    setTimeout(() => {
      const entries = Object.values(usersDB);
      const identityMatch = entries.find(entry => 
        entry.user.username === authIdentity || entry.user.email === authIdentity
      );

      if (!identityMatch) {
        alert("ACCESS DENIED: Identity not found.");
        setIsLoading(false);
        return;
      }

      if (identityMatch.key !== authKey) {
        alert("ACCESS DENIED: Invalid Cryptographic Key.");
        setIsLoading(false);
        return;
      }

      setCurrentUser(identityMatch.user);
      setIsAuthenticated(true);
      setStatus(VaultStatus.UNLOCKED);
      setIsLoading(false);
    }, 1800);
  };

  const proceedToSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateUsername(signupUsername)) {
      alert("Username must only contain small letters, numbers, and underscores.");
      return;
    }
    
    const entries = Object.values(usersDB);
    const emailExists = entries.some(entry => entry.user.email === signupEmail);
    if (emailExists) {
      alert("Email already registered in system.");
      return;
    }

    setSignupStep('SETUP');
  };

  const finalizeAccount = (e: React.FormEvent, isSkipping = false) => {
    e.preventDefault();
    
    let bName = isSkipping ? '' : signupBeneficiaryUsername;
    let bEmail = isSkipping ? '' : signupBeneficiaryEmail;

    setIsLoading(true);
    setLoadingMsg("PROVISIONING SECURE VAULT...");
    setTimeout(() => {
      const newKey = 'SENTINEL-' + Math.random().toString(36).substring(2, 15).toUpperCase() + '-' + Date.now().toString().slice(-4);
      const newUser: UserProfile = {
        id: 'u-' + Math.floor(Math.random() * 1000000),
        username: signupUsername,
        name: signupName,
        email: signupEmail,
        checkInInterval: signupInterval,
        checkInUnit: signupUnit,
        gracePeriodHours: 48,
        lastCheckIn: new Date().toISOString(),
        beneficiaryEmail: bEmail,
        beneficiaryName: bName,
        beneficiaryStatus: isSkipping ? 'PENDING' : 'APPROVED'
      };
      setUsersDB(prev => ({ ...prev, [newUser.id]: { user: newUser, key: newKey } }));
      setGeneratedKey(newKey);
      setIsLoading(false);
    }, 2000);
  };

  const handleCheckIn = () => {
    if (!currentUser) return;
    setIsLoading(true);
    setLoadingMsg("SYNCHRONIZING HEARTBEAT...");
    setTimeout(() => {
      const updated = { ...currentUser, lastCheckIn: new Date().toISOString() };
      setCurrentUser(updated);
      setUsersDB(prev => ({ ...prev, [updated.id]: { ...prev[updated.id], user: updated } }));
      setStatus(VaultStatus.UNLOCKED);
      setIsLoading(false);
      setShowDeadlineModal(true);
    }, 1200);
  };

  const updateDeadline = (val: number, unit: DeadlineUnit) => {
    if (!currentUser) return;
    const updated = { ...currentUser, checkInInterval: val, checkInUnit: unit };
    setCurrentUser(updated);
    setUsersDB(prev => ({ ...prev, [updated.id]: { ...prev[updated.id], user: updated } }));
    setShowDeadlineModal(false);
  };

  const openNotepad = (secret?: Secret) => {
    if (secret) {
      setEditingSecretId(secret.id);
      setNotepadTitle(secret.title);
      setNotepadContent(secret.content);
      setNotepadImages(secret.images || []);
    } else {
      setEditingSecretId(null);
      setNotepadTitle('');
      setNotepadContent('');
      setNotepadImages([]);
    }
    setIsNotepadOpen(true);
  };

  const closeNotepad = () => {
    setIsNotepadOpen(false);
    setEditingSecretId(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setNotepadImages(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const saveAsset = () => {
    if (!notepadTitle.trim()) {
      alert("Please provide a title for this secret asset.");
      return;
    }
    setIsLoading(true);
    setLoadingMsg("ENCRYPTING & RELAYING TO IPFS...");
    setTimeout(() => {
      const now = new Date().toISOString();
      if (editingSecretId) {
        setSecrets(prev => prev.map(s => s.id === editingSecretId ? {
          ...s,
          title: notepadTitle,
          content: notepadContent,
          images: notepadImages,
          lastEditedAt: now
        } : s));
      } else {
        const newSecret: Secret = {
          id: 's-' + Math.floor(Math.random() * 1000000),
          title: notepadTitle,
          content: notepadContent,
          images: notepadImages,
          type: 'NOTE',
          createdAt: now,
          lastEditedAt: now
        };
        setSecrets(prev => [newSecret, ...prev]);
      }
      setIsLoading(false);
      closeNotepad();
    }, 1200);
  };

  useEffect(() => {
    if (!currentUser || !isAuthenticated) return;
    const interval = setInterval(() => {
      const now = new Date();
      const lastCheckIn = new Date(currentUser.lastCheckIn);
      const diffMs = now.getTime() - lastCheckIn.getTime();
      const limitMs = currentUser.checkInInterval * UNIT_TO_SECONDS[currentUser.checkInUnit] * 1000;
      const remainingMs = Math.max(0, limitMs - diffMs);
      setTimeLeft(Math.floor(remainingMs / 1000)); 
      if (remainingMs <= 0 && status !== VaultStatus.TRANSFER_SEQUENCE) {
        setStatus(VaultStatus.TRANSFER_SEQUENCE);
        setGraceTimeLeft(currentUser.gracePeriodHours * 3600);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [currentUser, isAuthenticated, status]);

  const formatTimeRemaining = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${d > 0 ? d + 'd ' : ''}${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 relative">
        <AuthBackground />
        {isLoading && <LoadingOverlay message={loadingMsg} />}
        
        <div className="glass max-w-lg w-full p-10 rounded-[2.5rem] neon-border relative overflow-hidden animate-in fade-in zoom-in duration-500 shadow-2xl">
          <div className="flex justify-center mb-8">
            <div className="p-5 bg-green-500/10 rounded-full animate-pulse-glow">
              <Shield className="w-14 h-14 text-green-500 animate-float" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-center mb-2 tracking-tight text-white uppercase tracking-tighter neon-text">SENTINEL <span className="text-green-500 font-light">Vault</span></h1>
          
          {generatedKey ? (
            <div className="space-y-6 animate-in slide-in-from-bottom duration-500">
              <div className="p-5 bg-red-500/10 border border-red-500/30 rounded-2xl crt-flicker">
                <p className="text-[11px] text-red-500 font-bold uppercase mono mb-1">CRITICAL: SECURE THIS KEY</p>
                <p className="text-[12px] text-gray-300 uppercase mono leading-relaxed">This key is non-custodial. If lost, your vault data is unrecoverable.</p>
              </div>
              <div className="relative group overflow-hidden rounded-xl border border-green-500/30">
                <div className="absolute inset-0 bg-green-500/5"></div>
                <div className="w-full bg-black/40 py-6 px-4 mono text-xs text-green-400 break-all pr-12 text-center relative z-10">{generatedKey}</div>
                <button onClick={() => copyToClipboard(generatedKey)} className="absolute right-2 top-1/2 -translate-y-1/2 p-3 hover:bg-white/10 rounded-xl transition-all text-gray-400 hover:text-white z-20">
                  {hasCopiedKey ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                </button>
              </div>
              <button onClick={() => { setIsSigningUp(false); setGeneratedKey(null); setSignupStep('INFO'); }} className="w-full py-5 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-bold transition-all uppercase tracking-[0.2em] text-xs">Access Finalized</button>
            </div>
          ) : isSigningUp ? (
            <div className="space-y-6">
               <p className="text-gray-400 text-center text-[11px] mono uppercase tracking-widest mb-4">{signupStep === 'INFO' ? 'Identity Initialization' : 'Vault Protocol Setup'}</p>
               {signupStep === 'INFO' ? (
                 <form onSubmit={proceedToSetup} className="space-y-4">
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Unique Identifier</label>
                      <input type="text" required value={signupUsername} onChange={(e) => setSignupUsername(e.target.value.toLowerCase())} className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs focus:ring-1 focus:ring-green-500 outline-none mono text-white" placeholder="agent_007" />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Display Name</label>
                      <input type="text" required value={signupName} onChange={(e) => setSignupName(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs focus:ring-1 focus:ring-green-500 outline-none text-white" placeholder="Primary User" />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Security Email</label>
                      <input type="email" required value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs mono focus:ring-1 focus:ring-green-500 outline-none text-white" placeholder="security@sentinel.io" />
                    </div>
                    <button type="submit" className="w-full py-4 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl font-bold transition-all flex items-center justify-center space-x-2 uppercase tracking-widest text-xs group">
                      <span>Proceed to Protocols</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                 </form>
               ) : (
                 <form onSubmit={(e) => finalizeAccount(e)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-2">
                          <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Heir ID</label>
                          <input type="text" value={signupBeneficiaryUsername} onChange={(e) => setSignupBeneficiaryUsername(e.target.value.toLowerCase())} className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs focus:ring-1 focus:ring-green-500 outline-none mono text-white" placeholder="successor_01" />
                       </div>
                       <div className="space-y-2">
                          <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Heir Email</label>
                          <input type="email" value={signupBeneficiaryEmail} onChange={(e) => setSignupBeneficiaryEmail(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl py-3 px-4 text-xs mono focus:ring-1 focus:ring-green-500 outline-none text-white" placeholder="heir@email.com" />
                       </div>
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[10px] uppercase tracking-widest text-gray-400 mono">Heartbeat Timeout</label>
                      <div className="flex space-x-2">
                        <input type="number" min="1" value={signupInterval} onChange={(e) => setSignupInterval(parseInt(e.target.value))} className="flex-1 bg-black/40 border border-white/10 rounded-xl py-3 px-4 mono text-center text-lg font-bold text-white outline-none" />
                        <select value={signupUnit} onChange={(e) => setSignupUnit(e.target.value as any)} className="bg-black/40 border border-white/10 rounded-xl px-4 text-[10px] uppercase mono outline-none text-white">
                           <option value="HOURS">Hrs</option>
                           <option value="DAYS">Days</option>
                           <option value="WEEKS">Wks</option>
                           <option value="MONTHS">Mo</option>
                        </select>
                      </div>
                    </div>
                    <button type="submit" className="w-full py-5 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-bold transition-all uppercase tracking-widest text-xs shadow-xl shadow-green-900/20 active:scale-95">Initialize Secure Loop</button>
                    <button type="button" onClick={(e) => finalizeAccount(e, true)} className="w-full py-3 text-gray-500 hover:text-white rounded-xl text-[10px] font-bold uppercase mono transition-all">Skip Inheritance Protocol</button>
                 </form>
               )}
               <button onClick={() => { setIsSigningUp(false); setSignupStep('INFO'); }} className="w-full text-[10px] text-gray-600 hover:text-green-400 mono transition-all uppercase tracking-widest">Back to Entry</button>
            </div>
          ) : (
            <form onSubmit={handleLogin} className="space-y-8 stagger-in">
              <p className="text-gray-400 text-center text-[11px] mono uppercase tracking-widest">Master Authorization</p>
              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="block text-[10px] uppercase tracking-widest text-gray-500 mono">Access Identity</label>
                  <div className="relative group">
                    <Fingerprint className="absolute left-3 top-3 w-4 h-4 text-gray-600 transition-colors group-focus-within:text-green-500" />
                    <input type="text" required value={authIdentity} onChange={(e) => setAuthIdentity(e.target.value)} placeholder="Username or Email" className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:ring-1 focus:ring-green-500 outline-none text-xs mono text-white focus:bg-black/60 transition-all" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="block text-[10px] uppercase tracking-widest text-gray-500 mono">Cryptographic Master Key</label>
                  <div className="relative group">
                    <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-600 transition-colors group-focus-within:text-green-500" />
                    <input type="password" required value={authKey} onChange={(e) => setAuthKey(e.target.value)} placeholder="SENTINEL-XXXX..." className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 focus:ring-1 focus:ring-green-500 outline-none text-xs mono text-white focus:bg-black/60 transition-all" />
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-bold transition-all flex items-center justify-center space-x-2 shadow-lg uppercase tracking-[0.2em] text-xs active:scale-95">
                <Unlock className="w-4 h-4" />
                <span>Initialize Vault</span>
              </button>
              <button type="button" onClick={() => setIsSigningUp(true)} className="w-full text-[10px] text-gray-600 hover:text-green-400 mono transition-all uppercase tracking-widest">Request System Account</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-black text-white overflow-hidden font-sans">
      <SecurityBackground />
      {isLoading && <LoadingOverlay message={loadingMsg} />}

      {isNotepadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/90 backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="glass max-w-2xl w-full h-[85vh] flex flex-col rounded-[2.5rem] border border-white/10 overflow-hidden animate-in zoom-in duration-300 shadow-2xl">
            <div className="p-8 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                <div className="p-2 bg-green-500/10 rounded-lg"><Edit3 className="w-5 h-5 text-green-500" /></div>
                <input 
                  type="text" 
                  value={notepadTitle} 
                  onChange={(e) => setNotepadTitle(e.target.value)}
                  placeholder="Asset Filename..."
                  className="bg-transparent text-2xl font-bold outline-none focus:text-green-400 transition-colors w-full"
                />
              </div>
              <button onClick={closeNotepad} className="p-2 hover:bg-white/10 rounded-full transition-all ml-4">
                <X className="w-6 h-6 text-gray-500 hover:text-white" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-8">
              <textarea 
                value={notepadContent}
                onChange={(e) => setNotepadContent(e.target.value)}
                placeholder="Secure note content. Locally encrypted."
                className="w-full h-64 bg-transparent border-none outline-none resize-none mono text-sm leading-relaxed text-gray-300 focus:text-white transition-colors"
              />
              {notepadImages.length > 0 && (
                <div className="space-y-4">
                  <h4 className="text-[10px] uppercase tracking-[0.3em] text-gray-500 mono font-bold border-b border-white/5 pb-2">Encrypted Visual Data</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {notepadImages.map((img, idx) => (
                      <div key={idx} className="relative group rounded-xl overflow-hidden aspect-square border border-white/10 bg-white/5">
                        <img src={img} className="w-full h-full object-cover" alt="Secret Intel" />
                        <button onClick={() => setNotepadImages(prev => prev.filter((_, i) => i !== idx))} className="absolute top-2 right-2 p-2 bg-red-600/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="p-8 border-t border-white/5 flex items-center justify-between">
              <button onClick={() => notepadFileInputRef.current?.click()} className="flex items-center space-x-2 px-5 py-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all text-[10px] font-bold uppercase mono border border-white/10">
                <ImageIcon className="w-4 h-4 text-green-500" />
                <span>Attach Media</span>
                <input type="file" ref={notepadFileInputRef} className="hidden" onChange={handleImageUpload} multiple accept="image/*" />
              </button>
              <button onClick={saveAsset} className="flex items-center space-x-2 px-8 py-4 bg-green-600 hover:bg-green-500 text-white rounded-2xl font-bold uppercase tracking-widest text-xs active:scale-95 shadow-xl shadow-green-900/40">
                <Save className="w-4 h-4" />
                <span>Sync with Vault</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar Navigation */}
      <nav className="w-full md:w-72 glass border-r border-white/5 p-8 flex flex-col z-10">
        <div className="flex items-center space-x-3 mb-12 animate-float">
          <div className="p-3 bg-green-500/10 rounded-2xl shadow-inner"><ShieldCheck className="w-8 h-8 text-green-500" /></div>
          <span className="font-bold tracking-tighter text-2xl uppercase text-white neon-text">Sentinel</span>
        </div>
        <div className="flex-1 space-y-4">
          {[
            { id: 'vault', label: 'Secured Assets', icon: Lock },
            { id: 'beneficiary', label: 'Heir Protocol', icon: User },
            { id: 'emergency', label: 'Sudden Access', icon: AlertTriangle }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)} 
                className={`w-full flex items-center space-x-4 px-5 py-4 rounded-[1.5rem] transition-all group ${activeTab === tab.id ? 'bg-green-500/20 text-green-400 border border-green-500/30 shadow-lg shadow-green-900/10' : 'text-gray-500 hover:text-white hover:bg-white/5 border border-transparent'}`}
              >
                <Icon className={`w-5 h-5 transition-transform group-hover:scale-110 ${activeTab === tab.id ? 'animate-pulse' : ''}`} />
                <span className="font-bold uppercase tracking-widest text-[10px]">{tab.label}</span>
              </button>
            );
          })}
        </div>
        <div className="pt-8 border-t border-white/5 mt-auto">
          <div className="flex items-center space-x-4 mb-8 p-4 rounded-2xl bg-white/5 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-600 to-green-950 flex items-center justify-center font-bold text-white shadow-xl">{currentUser?.username[0].toUpperCase()}</div>
            <div className="overflow-hidden">
              <p className="text-[10px] text-gray-500 uppercase mono truncate">@{currentUser?.username}</p>
              <p className="text-sm font-bold truncate text-white uppercase">{currentUser?.name}</p>
            </div>
          </div>
          <button onClick={() => setIsAuthenticated(false)} className="w-full flex items-center space-x-3 px-5 py-4 text-red-500/70 hover:text-red-500 hover:bg-red-500/10 rounded-2xl transition-all uppercase text-[10px] font-bold mono border border-transparent hover:border-red-500/20 active:scale-95">
            <LogOut className="w-4 h-4" /><span>Suspend Access</span>
          </button>
        </div>
      </nav>

      {/* Main Display */}
      <main className="flex-1 overflow-y-auto p-6 md:p-12 relative z-0">
        <div className="flex flex-col lg:flex-row items-center justify-between mb-12 space-y-6 lg:space-y-0 bg-white/5 p-8 rounded-[2.5rem] border border-white/5 backdrop-blur-xl animate-in slide-in-from-top duration-700 shadow-2xl">
          <div className="flex flex-wrap items-center gap-12">
            <div className="space-y-2 text-center lg:text-left">
              <p className="text-[10px] uppercase tracking-[0.3em] text-gray-500 mono font-bold">System Integrity</p>
              <div className="flex items-center justify-center lg:justify-start space-x-3">
                <div className={`w-3 h-3 rounded-full shadow-[0_0_12px_rgba(34,197,94,0.6)] ${status === VaultStatus.UNLOCKED ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                <span className={`font-bold tracking-tight text-2xl uppercase ${status === VaultStatus.UNLOCKED ? 'text-green-400 neon-text' : 'text-red-400'}`}>{status.replace('_', ' ')}</span>
              </div>
            </div>
            <div className="h-12 w-[1px] bg-white/10 hidden lg:block" />
            <div className="space-y-2 text-center lg:text-left">
              <p className="text-[10px] uppercase tracking-[0.3em] text-gray-500 mono font-bold">Heartbeat Signal</p>
              <div className="flex items-center justify-center lg:justify-start space-x-6">
                <span className="font-bold tracking-tighter text-3xl text-white mono tabular-nums">{formatTimeRemaining(timeLeft)}</span>
                <button onClick={handleCheckIn} className="px-6 py-3 bg-green-500/10 text-green-400 rounded-xl hover:bg-green-500/20 transition-all flex items-center space-x-3 uppercase font-bold text-[10px] tracking-widest border border-green-500/20 group">
                  <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" /><span>Recalibrate</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="animate-in slide-in-from-bottom duration-700 relative min-h-[600px] rounded-[3rem] overflow-hidden">
          {activeTab === 'vault' && (
            <div className="space-y-10 relative p-10 z-10">
              {/* Local Video Background for Secured Assets Section */}
              <div className="absolute inset-0 -z-10 pointer-events-none rounded-[3rem] overflow-hidden">
                <video 
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover opacity-80 contrast-125 brightness-95 scale-100"
                >
                  <source src="https://cdn.pixabay.com/video/2018/07/04/17076-278405108_tiny.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-black/10 backdrop-blur-[1px]"></div>
              </div>

              <div className="flex items-center justify-between border-b border-white/20 pb-8">
                <div>
                  <h2 className="text-4xl font-bold tracking-tighter text-white uppercase drop-shadow-lg">Secured <span className="text-green-500 font-light">Inventory</span></h2>
                  <p className="text-xs text-white/80 mono uppercase tracking-widest mt-2 drop-shadow-md">Authenticated assets within the encrypted local partition.</p>
                </div>
                <button onClick={() => openNotepad()} className="flex items-center space-x-3 bg-green-600 hover:bg-green-500 text-white px-8 py-4 rounded-[1.5rem] transition-all text-[10px] font-bold uppercase tracking-[0.2em] shadow-2xl shadow-green-900/40 active:scale-95 group">
                  <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" /><span>Inject Data</span>
                </button>
              </div>
              
              {secrets.length === 0 ? (
                <div className="h-[400px] border border-dashed border-white/40 rounded-[3rem] flex flex-col items-center justify-center text-white space-y-6 bg-black/30 backdrop-blur-md relative overflow-hidden">
                  <div className="scan-effect opacity-50"></div>
                  <Lock className="w-16 h-16 opacity-30 animate-float" />
                  <p className="text-[11px] mono uppercase tracking-widest text-center max-w-xs text-white drop-shadow-md">No active assets found. Initialize storage by injecting your first secret payload.</p>
                  <button onClick={() => openNotepad()} className="bg-white/10 border border-white/20 px-10 py-4 rounded-2xl hover:bg-white/20 transition-all text-[10px] font-bold uppercase mono text-green-400 backdrop-blur-xl">Launch Injection Mode</button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 stagger-in">
                  {secrets.map(s => (
                    <div key={s.id} onClick={() => openNotepad(s)} className="glass p-8 rounded-[2.5rem] border border-white/20 hover:border-green-500/60 transition-all group cursor-pointer relative overflow-hidden shadow-2xl bg-black/40 backdrop-blur-xl">
                      <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-opacity"><Edit3 className="w-5 h-5 text-green-500" /></div>
                      <div className="flex items-start justify-between mb-8">
                        <div className="p-4 bg-white/10 rounded-2xl group-hover:bg-green-500/20 transition-all border border-white/10"><FileText className="w-8 h-8 text-white/70 group-hover:text-green-500" /></div>
                        <span className="text-[9px] text-white/60 mono uppercase font-bold tracking-widest bg-white/10 px-4 py-1.5 rounded-full border border-white/10">{s.images && s.images.length > 0 ? 'Media Enc.' : 'Text Enc.'}</span>
                      </div>
                      <h3 className="font-bold text-2xl mb-3 tracking-tighter text-white uppercase group-hover:text-green-400 transition-colors drop-shadow-md">{s.title}</h3>
                      <p className="text-[11px] text-white/60 mono line-clamp-3 h-12">{s.content || "Empty payload structure..."}</p>
                      <div className="pt-6 border-t border-white/10 mt-6 flex justify-between text-[9px] text-white/50 mono uppercase">
                        <span>Synced</span>
                        <span className="text-green-500/80">{new Date(s.lastEditedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'beneficiary' && (
            <div className="space-y-10 relative p-10 z-10 min-h-[600px]">
              {/* Local Video Background for Heir Protocol Section */}
              <div className="absolute inset-0 -z-10 pointer-events-none rounded-[3rem] overflow-hidden">
                <video 
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover opacity-80 contrast-125 brightness-95 scale-100"
                >
                  <source src="https://cdn.pixabay.com/video/2018/07/04/17076-278405108_tiny.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]"></div>
              </div>

              <div className="max-w-4xl space-y-10 relative z-20">
                <h2 className="text-4xl font-bold tracking-tighter text-white uppercase drop-shadow-lg">Succession <span className="text-green-500 font-light">Protocol</span></h2>
                <div className="glass p-12 rounded-[3.5rem] space-y-12 border-white/20 relative shadow-2xl overflow-hidden bg-black/40 backdrop-blur-xl">
                  <div className="scan-effect opacity-20"></div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-2">
                      <p className="text-[10px] uppercase tracking-[0.3em] text-white/60 mono font-bold">Primary Successor</p>
                      <p className="text-4xl font-bold uppercase tracking-tighter text-white neon-text drop-shadow-md">{currentUser?.beneficiaryName || 'No Heir Assigned'}</p>
                      <p className="text-sm text-white/70 mono tracking-wider">{currentUser?.beneficiaryEmail || 'Update protocol details below'}</p>
                    </div>
                    <div className={`px-6 py-2 rounded-full text-[10px] font-bold uppercase mono border ${currentUser?.beneficiaryStatus === 'APPROVED' ? 'bg-green-500/20 text-green-400 border-green-500/40 shadow-[0_0_15px_rgba(34,197,94,0.3)]' : 'bg-orange-500/20 text-orange-400 border-orange-500/40'}`}>
                      Status: {currentUser?.beneficiaryStatus}
                    </div>
                  </div>
                  <div className="p-8 bg-white/5 border border-white/10 rounded-[2.5rem] flex items-start space-x-6 relative backdrop-blur-md">
                    <UserCheck className="w-8 h-8 text-green-500 shrink-0 mt-1" />
                    <p className="text-[11px] text-white/70 leading-relaxed uppercase mono tracking-widest">Upon Heartbeat failure, the system will initiate a challenge window. If unresponded, all vault assets are released to this entity via encrypted email relay.</p>
                  </div>
                  {!isAddingBeneficiary ? (
                    <button onClick={() => setIsAddingBeneficiary(true)} className="w-full py-6 bg-white/10 hover:bg-white/20 border border-white/20 rounded-[1.5rem] transition-all text-xs font-bold uppercase tracking-[0.3em] text-white backdrop-blur-xl shadow-2xl">Reconfigure Successor</button>
                  ) : (
                    <div className="space-y-6 pt-6 border-t border-white/20 animate-in slide-in-from-bottom duration-300">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] uppercase mono text-white/60">Successor Identity</label>
                          <input type="text" value={tabBeneficiaryUsername} onChange={(e) => setTabBeneficiaryUsername(e.target.value)} className="w-full bg-black/60 border border-white/20 rounded-xl py-4 px-6 text-sm mono text-white outline-none focus:border-green-500/50" placeholder="Heir Username" />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] uppercase mono text-white/60">Security Email</label>
                          <input type="email" value={tabBeneficiaryEmail} onChange={(e) => setTabBeneficiaryEmail(e.target.value)} className="w-full bg-black/60 border border-white/20 rounded-xl py-4 px-6 text-sm mono text-white outline-none focus:border-green-500/50" placeholder="heir@email.com" />
                        </div>
                      </div>
                      <div className="flex space-x-4">
                        <button onClick={() => setIsAddingBeneficiary(false)} className="flex-1 py-4 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] uppercase font-bold mono border border-white/10">Cancel</button>
                        <button onClick={() => {
                          const updated = { ...currentUser!, beneficiaryName: tabBeneficiaryUsername, beneficiaryEmail: tabBeneficiaryEmail, beneficiaryStatus: 'APPROVED' as any };
                          setCurrentUser(updated);
                          setUsersDB(prev => ({ ...prev, [updated.id]: { ...prev[updated.id], user: updated } }));
                          setIsAddingBeneficiary(false);
                        }} className="flex-[2] py-4 bg-green-600 hover:bg-green-500 rounded-xl text-[10px] uppercase font-bold mono shadow-xl shadow-green-900/40">Authorize Successor</button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'emergency' && (
            <div className="space-y-10 relative p-10 z-10 min-h-[600px]">
              {/* Local Video Background for Emergency Override Section */}
              <div className="absolute inset-0 -z-10 pointer-events-none rounded-[3rem] overflow-hidden">
                <video 
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover opacity-85 contrast-125 brightness-95 scale-100"
                >
                  <source src="https://cdn.pixabay.com/video/2018/07/04/17076-278405108_tiny.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]"></div>
              </div>

              <div className="max-w-5xl space-y-10 relative z-20">
                <h2 className="text-4xl font-bold tracking-tighter text-red-500 uppercase drop-shadow-lg">Emergency <span className="text-white font-light">Override</span></h2>
                <div className="glass p-16 rounded-[4rem] space-y-12 border-red-500/30 shadow-2xl relative overflow-hidden group bg-black/40 backdrop-blur-xl">
                  <div className="absolute inset-0 bg-red-950/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <div className="flex flex-col lg:flex-row items-center gap-12 relative z-10">
                    <div className="p-10 bg-red-500/20 rounded-[3rem] shadow-[0_0_50px_rgba(239,68,68,0.3)] animate-pulse border border-red-500/20"><AlertTriangle className="w-24 h-24 text-red-500" /></div>
                    <div className="space-y-4 text-center lg:text-left">
                      <h3 className="text-3xl font-bold uppercase tracking-tighter text-white drop-shadow-md">Sudden Incapacity Claim</h3>
                      <p className="text-sm text-white/70 leading-relaxed uppercase mono text-[11px] max-w-xl tracking-wider">Manual trigger by Heir entity. This overrides the Sentinel Heartbeat and initiates a 48-hour challenge cycle. If no heartbeat recalibration occurs within this window, the Vault opens.</p>
                    </div>
                  </div>
                  <button 
                    disabled={!currentUser?.beneficiaryEmail}
                    onClick={() => alert("EMERGENCY OVERRIDE SEQUENCE INITIATED. 48-HOUR CHALLENGE WINDOW OPEN.")}
                    className="w-full py-8 bg-red-600 hover:bg-red-500 text-white rounded-[2.5rem] font-bold transition-all shadow-2xl uppercase tracking-[0.4em] text-sm disabled:bg-gray-800 disabled:text-gray-600 active:scale-95 border border-red-500/20 backdrop-blur-xl"
                  >
                    Request Emergency Transfer
                  </button>
                  {!currentUser?.beneficiaryEmail && <p className="text-center text-red-400 mono text-[10px] font-bold uppercase drop-shadow-md">No heir protocol assigned for override.</p>}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Deadline Reset Modal */}
      {showDeadlineModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-300">
          <div className="glass max-w-md w-full p-12 rounded-[3.5rem] border border-green-500/30 animate-in zoom-in duration-500 shadow-2xl text-center relative overflow-hidden">
            <div className="scan-effect opacity-30"></div>
            <div className="flex justify-center mb-10"><Clock className="w-16 h-16 text-green-500 animate-pulse" /></div>
            <h3 className="text-2xl font-bold uppercase tracking-tight text-white mb-4">Heartbeat Synchronized</h3>
            <p className="text-xs text-gray-500 mono uppercase mb-10 leading-relaxed">Identity verified. Configure next switch timeout interval.</p>
            <div className="flex space-x-3 mb-10">
              <input type="number" min="1" value={signupInterval} onChange={(e) => setSignupInterval(parseInt(e.target.value))} className="flex-1 bg-black/50 border border-white/10 rounded-[1.5rem] py-6 text-3xl font-bold mono text-white text-center outline-none focus:border-green-500/50" />
              <select value={signupUnit} onChange={(e) => setSignupUnit(e.target.value as any)} className="bg-black/50 border border-white/10 rounded-[1.5rem] px-6 text-[11px] uppercase mono text-white">
                <option value="HOURS">Hrs</option>
                <option value="DAYS">Days</option>
                <option value="WEEKS">Wks</option>
                <option value="MONTHS">Mo</option>
              </select>
            </div>
            <button onClick={() => updateDeadline(signupInterval, signupUnit)} className="w-full py-6 bg-green-600 hover:bg-green-500 text-white rounded-[2rem] text-xs font-bold uppercase tracking-[0.3em] transition-all shadow-xl active:scale-95">Update Security Loop</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
