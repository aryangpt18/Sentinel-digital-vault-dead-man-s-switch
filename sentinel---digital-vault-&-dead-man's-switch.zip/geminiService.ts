
import { GoogleGenAI, Type, Modality } from "@google/genai";

export class GeminiService {
  constructor() {}

  // Complex reasoning for security audits or planning
  async thinkingTask(prompt: string) {
    try {
      // Use process.env.API_KEY directly and instantiate right before calling generateContent
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: prompt,
        config: { 
          thinkingConfig: { thinkingBudget: 32768 } 
        },
      });
      return response.text;
    } catch (error: any) {
      // Handle the case where the API key might be missing or invalid
      if (error?.message?.includes("Requested entity was not found")) {
        console.error("API Key not found or project not configured. Use window.aistudio.openSelectKey() to set one.");
      }
      console.error("Thinking error:", error);
      throw error;
    }
  }

  // Fast AI for simple UI helpers
  async fastResponse(prompt: string) {
    // Instantiate right before calling generateContent with corrected model name
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-flash-lite-latest",
      contents: prompt,
    });
    return response.text;
  }

  // Search Grounding for current info
  async searchInfo(query: string) {
    // Instantiate right before calling generateContent
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  }

  // Image Generation (Pro)
  async generateImage(prompt: string, size: "1K" | "2K" | "4K" = "1K") {
    // Instantiate right before calling generateContent for image models
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size
        }
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated");
  }

  // Image Editing (Flash Image)
  async editImage(base64Image: string, prompt: string, mimeType: string = 'image/png') {
    // Instantiate right before calling generateContent
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Image.split(',')[1], mimeType } },
          { text: prompt },
        ],
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("Failed to edit image");
  }

  // Video Generation (Veo)
  async generateVideo(base64Image: string, prompt: string, mimeType: string = 'image/png') {
    // Instantiate right before calling generateVideos for Veo models
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      image: {
        imageBytes: base64Image.split(',')[1],
        mimeType: mimeType,
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  }
}

export const gemini = new GeminiService();
