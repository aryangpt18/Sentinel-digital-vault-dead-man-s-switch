
export enum VaultStatus {
  LOCKED = 'LOCKED',
  UNLOCKED = 'UNLOCKED',
  TRANSFER_SEQUENCE = 'TRANSFER_SEQUENCE',
  EMERGENCY_REQUESTED = 'EMERGENCY_REQUESTED',
  TRANSFERRED = 'TRANSFERRED'
}

export interface Secret {
  id: string;
  title: string;
  type: 'PASSWORD' | 'NOTE' | 'IMAGE' | 'VIDEO' | 'CREDENTIAL';
  content: string;
  images?: string[]; // Array of base64 strings
  createdAt: string;
  lastEditedAt: string;
  ipfsHash?: string;
}

export type BeneficiaryStatus = 'PENDING' | 'APPROVED';

export type DeadlineUnit = 'MINUTES' | 'HOURS' | 'DAYS' | 'WEEKS' | 'MONTHS' | 'YEARS';

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  email: string;
  checkInInterval: number;
  checkInUnit: DeadlineUnit;
  gracePeriodHours: number;
  lastCheckIn: string;
  beneficiaryEmail: string;
  beneficiaryName: string;
  beneficiaryStatus: BeneficiaryStatus;
}

export interface AIState {
  isThinking: boolean;
  isGenerating: boolean;
  error: string | null;
}
